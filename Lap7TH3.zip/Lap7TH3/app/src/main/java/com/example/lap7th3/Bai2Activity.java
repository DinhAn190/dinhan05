package com.example.lap7th3;

import android.app.Dialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Bai2Activity extends AppCompatActivity {

    Button btnToast, btnDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);

        btnToast = findViewById(R.id.btnToast);
        btnDialog = findViewById(R.id.btnDialog);

        // Custom Toast
        btnToast.setOnClickListener(v -> {
            LayoutInflater inflater = getLayoutInflater();
            View layout = inflater.inflate(R.layout.custom_toast, null);

            Toast toast = new Toast(getApplicationContext());
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.setDuration(Toast.LENGTH_LONG);
            toast.setView(layout);
            toast.show();
        });

        // Custom Dialog
        btnDialog.setOnClickListener(v -> {
            final Dialog dialog = new Dialog(Bai2Activity.this);
            dialog.setContentView(R.layout.custom_dialog);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

            Button btnOk = dialog.findViewById(R.id.btnOk);
            Button btnClose = dialog.findViewById(R.id.btnCloseDialog);

            btnClose.setOnClickListener(view -> dialog.dismiss());
            btnOk.setOnClickListener(view -> {
                // Có thể xử lý đăng nhập ở đây
                Toast.makeText(Bai2Activity.this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });

            dialog.show();
        });
    }
}