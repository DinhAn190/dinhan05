package com.example.lap7th3;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class CustomActivity extends AppCompatActivity {

    Button btnCustom, btnToast, btnDialog;
    SeekBar seekR, seekG, seekB;
    View colorPreview;
    TextView tvCMY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom);

        btnCustom = findViewById(R.id.btnCustom);
        btnToast = findViewById(R.id.btnToast);
        btnDialog = findViewById(R.id.btnDialog);
        seekR = findViewById(R.id.seekR);
        seekG = findViewById(R.id.seekG);
        seekB = findViewById(R.id.seekB);
        colorPreview = findViewById(R.id.colorPreview);
        tvCMY = findViewById(R.id.tvCMY);

        btnToast.setOnClickListener(v -> showCustomToast("Đây là Custom Toast!"));
        btnDialog.setOnClickListener(v -> showCustomDialog());

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateColorPreview();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        };

        seekR.setOnSeekBarChangeListener(listener);
        seekG.setOnSeekBarChangeListener(listener);
        seekB.setOnSeekBarChangeListener(listener);

        seekR.setProgress(100);
        seekG.setProgress(150);
        seekB.setProgress(200);
        updateColorPreview();
    }

    private void showCustomToast(String msg) {
        View layout = getLayoutInflater().inflate(R.layout.layout_custom_toast, null);
        TextView tv = layout.findViewById(R.id.tvToast);
        tv.setText(msg);

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }

    private void showCustomDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.layout_custom_dialog, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        Button ok = view.findViewById(R.id.btnDialogOk);
        Button cancel = view.findViewById(R.id.btnDialogCancel);

        ok.setOnClickListener(v -> {
            showCustomToast("Bạn đã chọn OK");
            dialog.dismiss();
        });

        cancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    private void updateColorPreview() {
        int r = seekR.getProgress();
        int g = seekG.getProgress();
        int b = seekB.getProgress();

        int color = Color.rgb(r, g, b);
        colorPreview.setBackgroundColor(color);

        int c = 255 - r;
        int m = 255 - g;
        int y = 255 - b;

        tvCMY.setText(
                String.format("RGB(%d, %d, %d) → CMY(%d, %d, %d)", r, g, b, c, m, y)
        );
    }
}
