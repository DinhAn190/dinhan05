package com.example.lap7th3;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class Bai1Activity extends AppCompatActivity {

    Button btnRed, btnGreen;
    ImageView imgFace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1);

        btnRed = findViewById(R.id.btnRed);
        btnGreen = findViewById(R.id.btnGreen);
        imgFace = findViewById(R.id.imgFace);

        // Màu đỏ
        btnRed.setOnClickListener(v ->
                imgFace.setColorFilter(Color.RED)
        );

        // Màu xanh lá
        btnGreen.setOnClickListener(v ->
                imgFace.setColorFilter(Color.GREEN)
        );
    }
}
