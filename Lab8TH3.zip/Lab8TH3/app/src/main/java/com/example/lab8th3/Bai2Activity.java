package com.example.lab8th3;

import android.os.Bundle;
import android.widget.GridView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class Bai2Activity extends AppCompatActivity {

    GridView gridView;
    ArrayList<Contributor> list;
    ContributorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);

        gridView = findViewById(R.id.gridView);
        list = new ArrayList<>();

        // Dữ liệu giống hệt hình trang 8
        list.add(new Contributor("Maboo", 283297, R.drawable.maboo));
        list.add(new Contributor("SameOldShawn", 252433, R.drawable.sameoldshawn));
        list.add(new Contributor("Mowtive901", 184835, R.drawable.mowtive901));

        list.add(new Contributor("Brandon", 103486, R.drawable.brandon));
        list.add(new Contributor("Clement_RGF", 86332, R.drawable.clement_rgf));
        list.add(new Contributor("Nebja", 84187, R.drawable.nebja));

        list.add(new Contributor("BBDS", 81762, R.drawable.bbds));
        list.add(new Contributor("PleaseDo-ModMe", 78243, R.drawable.pleasedomodme));
        list.add(new Contributor("DLizzle", 76331, R.drawable.dlizzle));

        adapter = new ContributorAdapter(this, list);
        gridView.setAdapter(adapter);
    }
}