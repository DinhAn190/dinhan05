package com.example.lab8th3;

public class Contributor {
    private String name;
    private int points;
    private int avatar;

    public Contributor(String name, int points, int avatar) {
        this.name = name;
        this.points = points;
        this.avatar = avatar;
    }

    public String getName() { return name; }
    public int getPoints() { return points; }
    public int getAvatar() { return avatar; }
}