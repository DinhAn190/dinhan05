package com.example.lab8th3;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lvFood;
    ArrayList<Food> list;
    FoodAdapter adapter;
    int selectedPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvFood = findViewById(R.id.lvFood);
        findViewById(R.id.btnGoToBai2).setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, Bai2Activity.class));
        });
        list = new ArrayList<>();

        // Dữ liệu mẫu giống 100% hình
        list.add(new Food("Hamburger", 45000, R.drawable.hamburger));
        list.add(new Food("Pizza", 120000, R.drawable.pizza));
        list.add(new Food("Coca Cola", 15000, R.drawable.coca));
        list.add(new Food("Bánh mì thịt", 25000, R.drawable.banhmi));
        list.add(new Food("Gà rán", 35000, R.drawable.garan));
        list.add(new Food("Khoai tây chiên", 20000, R.drawable.khoaitay));
        list.add(new Food("Nước cam", 25000, R.drawable.nuoccam));

        adapter = new FoodAdapter(this, list);
        lvFood.setAdapter(adapter);

        // Đăng ký ContextMenu (nhấn giữ)
        registerForContextMenu(lvFood);

        // Lưu vị trí khi nhấn giữ
        lvFood.setOnItemLongClickListener((parent, view, position, id) -> {
            selectedPosition = position;
            return false;
        });
    }

    // Hiện ContextMenu khi nhấn giữ
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_menu, menu);
    }

    // Xử lý Sửa / Xóa
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_edit) {
            showAddEditDialog(true);
            return true;
        } else if (item.getItemId() == R.id.menu_delete) {
            list.remove(selectedPosition);
            adapter.notifyDataSetChanged();
            return true;
        }
        return super.onContextItemSelected(item);
    }

    // Tạo nút Menu (3 chấm) trên ActionBar để Thêm món
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.context_menu, menu); // Dùng lại menu để có icon +
        menu.findItem(R.id.menu_edit).setTitle("Thêm món mới");
        menu.findItem(R.id.menu_delete).setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_edit) {
            selectedPosition = -1;
            showAddEditDialog(false);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Dialog Thêm / Sửa
    private void showAddEditDialog(boolean isEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_add_edit, null);
        EditText edtName = view.findViewById(R.id.edtName);
        EditText edtPrice = view.findViewById(R.id.edtPrice);

        if (isEdit && selectedPosition != -1) {
            Food f = list.get(selectedPosition);
            edtName.setText(f.getName());
            edtPrice.setText(String.valueOf(f.getPrice()));
        }

        builder.setTitle(isEdit ? "Sửa món ăn" : "Thêm món mới")
                .setView(view)
                .setPositiveButton("OK", (dialog, which) -> {
                    String name = edtName.getText().toString().trim();
                    String priceStr = edtPrice.getText().toString().trim();
                    if (name.isEmpty() || priceStr.isEmpty()) return;

                    int price = Integer.parseInt(priceStr);

                    if (isEdit) {
                        Food f = list.get(selectedPosition);
                        f.setName(name);
                        f.setPrice(price);
                    } else {
                        list.add(new Food(name, price, R.drawable.hamburger)); // mặc định hình
                    }
                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }
}