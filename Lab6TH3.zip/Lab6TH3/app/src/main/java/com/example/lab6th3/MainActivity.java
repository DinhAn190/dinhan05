package com.example.lab6th3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.AnimationUtils;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etAmount;
    Spinner spFrom, spTo;
    Button btnConvert, btnClear, btnLength;
    TextView tvResult;
    RecyclerView rvHistory;

    ArrayList<String> historyList;
    HistoryAdapter historyAdapter;

    String[] currencies;
    String[] units;

    double[][] rate = {
            // USD   EUR     GBP     AUD     CAD     ZAR     NZD     JPY     INR     VND
            {1,     0.92,   0.80,   1.50,   1.34,   18.1,   1.61,   150,    83.5,   23000}, // USD
            {1.09,  1,      0.87,   1.63,   1.46,   19.7,   1.75,   163,    91.0,   25000}, // EUR
            {1.25,  1.15,   1,      1.87,   1.67,   22.7,   2.01,   187,    104,    28600}, // GBP
            {0.67,  0.61,   0.54,   1,      0.89,   12.1,   1.07,   100,    56.0,   15500}, // AUD
            {0.75,  0.68,   0.60,   1.12,   1,      13.6,   1.20,   112,    62.5,   17300}, // CAD
            {0.055, 0.051,  0.044,  0.083,  0.073,  1,      0.088,  9.19,   5.12,   1420},  // ZAR
            {0.62,  0.57,   0.50,   0.93,   0.83,   11.4,   1,      104,    58.0,   16000}, // NZD
            {0.0067,0.0061, 0.0053, 0.0093, 0.0084, 0.11,   0.0096, 1,      0.56,   154},   // JPY
            {0.012, 0.011,  0.0096, 0.018,  0.015,  0.20,   0.017,  1.79,   1,      275},   // INR
            {0.000043,0.000040,0.000035,0.000065,0.000058,0.0007,0.000062,0.0065,0.0036,1} // VND
    };


    SharedPreferences sharedPreferences;
    private final String PREFS_NAME = "CurrencyPrefs";
    private final String KEY_HISTORY = "HistoryList";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etAmount = findViewById(R.id.etAmount);
        spFrom = findViewById(R.id.spFrom);
        spTo = findViewById(R.id.spTo);
        btnConvert = findViewById(R.id.btnConvert);
        btnClear = findViewById(R.id.btnClear);
        btnLength = findViewById(R.id.btnLength);
        tvResult = findViewById(R.id.tvResult);
        rvHistory = findViewById(R.id.rvHistory);

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Load dữ liệu spinner
        currencies = getResources().getStringArray(R.array.currency_list);
        units = getResources().getStringArray(R.array.currency_unit);

        Log.d("DEBUG", "currencies.length=" + currencies.length + ", units.length=" + units.length);

        if (currencies.length == 0 || units.length == 0) {
            Toast.makeText(this, "Dữ liệu chưa được nạp đầy đủ!", Toast.LENGTH_LONG).show();
            return;
        }

        int[] flagList = {
                R.drawable.flag_us, R.drawable.flag_eu, R.drawable.flag_uk, R.drawable.flag_au,
                R.drawable.flag_ca, R.drawable.flag_za, R.drawable.flag_nz, R.drawable.flag_jp,
                R.drawable.flag_in, R.drawable.flag_vn
        };

        CurrencyAdapter adapter = new CurrencyAdapter(this, currencies, flagList);
        spFrom.setAdapter(adapter);
        spTo.setAdapter(adapter);

        // Lịch sử
        historyList = new ArrayList<>();
        loadHistory();

        historyAdapter = new HistoryAdapter(historyList, position -> {
            historyList.remove(position);
            historyAdapter.notifyItemRemoved(position);
            saveHistory();
        });

        rvHistory.setLayoutManager(new LinearLayoutManager(this));
        rvHistory.setAdapter(historyAdapter);

        // Nút Convert
        btnConvert.setOnClickListener(v -> convertCurrency());

        // Nút Clear
        btnClear.setOnClickListener(v -> {
            etAmount.setText("");
            tvResult.setText(getString(R.string.result_label));
            historyList.clear();
            historyAdapter.notifyDataSetChanged();
            saveHistory();
        });

        // Nút Length
        btnLength.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, LengthActivity.class);
            startActivity(i);
        });

        // Animation
        LinearLayout card = findViewById(R.id.cardMain);
        card.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        btnConvert.setBackgroundResource(R.drawable.bg_button_animated);
        AnimationDrawable anim = (AnimationDrawable) btnConvert.getBackground();
        anim.start();
    }

    private void convertCurrency() {
        if (currencies.length == 0 || units.length == 0 || rate.length == 0) {
            Toast.makeText(this, "Dữ liệu chưa được nạp đầy đủ!", Toast.LENGTH_SHORT).show();
            return;
        }

        String s = etAmount.getText().toString().trim();
        if (s.isEmpty()) {
            Toast.makeText(this, "Nhập số tiền", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(s);
        } catch (Exception e) {
            Toast.makeText(this, "Giá trị không hợp lệ", Toast.LENGTH_SHORT).show();
            return;
        }

        int iFrom = spFrom.getSelectedItemPosition();
        int iTo = spTo.getSelectedItemPosition();

        if (iFrom < 0 || iFrom >= rate.length || iTo < 0 || iTo >= rate[0].length) {
            Toast.makeText(this, "Vị trí chọn không hợp lệ!", Toast.LENGTH_SHORT).show();
            return;
        }

        double result = amount * rate[iFrom][iTo];
        DecimalFormat df = new DecimalFormat("#,###.####");
        String out = df.format(result) + " " + units[iTo];

        tvResult.setText(getString(R.string.result_label) + " " + out);

        String historyItem = df.format(amount) + " " + units[iFrom] + " → " + out;
        historyList.add(historyItem);
        historyAdapter.notifyItemInserted(historyList.size() - 1);
        saveHistory();
    }

    private void saveHistory() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        StringBuilder sb = new StringBuilder();
        for (String item : historyList) sb.append(item).append("||");
        editor.putString(KEY_HISTORY, sb.toString());
        editor.apply();
    }

    private void loadHistory() {
        String saved = sharedPreferences.getString(KEY_HISTORY, "");
        if (!saved.isEmpty()) {
            String[] items = saved.split("\\|\\|");
            for (String item : items) {
                if (!item.isEmpty()) historyList.add(item);
            }
        }
    }
}
