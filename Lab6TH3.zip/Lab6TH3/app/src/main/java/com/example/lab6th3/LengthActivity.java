package com.example.lab6th3;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

public class LengthActivity extends AppCompatActivity {
    EditText etLength;
    Spinner spFrom, spTo;
    Button btnConvert;
    TextView tvResult;

    String[] units = {"Millimeter (mm)","Centimeter (cm)","Meter (m)","Kilometer (km)","Inch (in)","Foot (ft)","Yard (yd)"};

    // ma trận tỉ lệ: value in i = ? in j
    double[][] rate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        etLength = findViewById(R.id.etLength);
        spFrom = findViewById(R.id.spLenFrom);
        spTo = findViewById(R.id.spLenTo);
        btnConvert = findViewById(R.id.btnLenConvert);
        tvResult = findViewById(R.id.tvLenResult);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFrom.setAdapter(adapter);
        spTo.setAdapter(adapter);

        prepareRateMatrix();

        btnConvert.setOnClickListener(v -> {
            String s = etLength.getText().toString().trim();
            if (s.isEmpty()) { Toast.makeText(this,"Nhập giá trị",Toast.LENGTH_SHORT).show(); return; }
            double val = Double.parseDouble(s);
            int iFrom = spFrom.getSelectedItemPosition();
            int iTo = spTo.getSelectedItemPosition();
            double res = val * rate[iFrom][iTo];
            DecimalFormat df = new DecimalFormat("#,###.####");
            tvResult.setText("Kết quả: " + df.format(res) + " " + units[iTo]);
        });
        // Animation
        LinearLayout card = findViewById(R.id.cardLayout);
        View root = findViewById(android.R.id.content);

// Fade-in toàn màn hình
        root.startAnimation(android.view.animation.AnimationUtils.loadAnimation(this, R.anim.fade_in));

// Slide card vào từ dưới
        card.startAnimation(android.view.animation.AnimationUtils.loadAnimation(this, R.anim.slide_up));

// Button animation
        btnConvert.setBackgroundResource(R.drawable.bg_button_animated);

// Pulse animation
        btnConvert.startAnimation(android.view.animation.AnimationUtils.loadAnimation(this, R.anim.pulse));

// Start gradient animation
        android.graphics.drawable.AnimationDrawable anim = (android.graphics.drawable.AnimationDrawable) btnConvert.getBackground();
        anim.start();

    }

    private void prepareRateMatrix() {
        // thứ tự: mm, cm, m, km, in, ft, yd
        rate = new double[7][7];
        // mm
        rate[0][0] = 1;
        rate[0][1] = 0.1;
        rate[0][2] = 0.001;
        rate[0][3] = 1e-6;
        rate[0][4] = 0.0393700787;
        rate[0][5] = 0.0032808399;
        rate[0][6] = 0.0010936133;
        // cm
        rate[1][0] = 10;
        rate[1][1] = 1;
        rate[1][2] = 0.01;
        rate[1][3] = 1e-5;
        rate[1][4] = 0.393700787;
        rate[1][5] = 0.032808399;
        rate[1][6] = 0.010936133;
        // m
        rate[2][0] = 1000;
        rate[2][1] = 100;
        rate[2][2] = 1;
        rate[2][3] = 0.001;
        rate[2][4] = 39.3700787;
        rate[2][5] = 3.2808399;
        rate[2][6] = 1.0936133;
        // km
        rate[3][0] = 1e6;
        rate[3][1] = 100000;
        rate[3][2] = 1000;
        rate[3][3] = 1;
        rate[3][4] = 39370.0787;
        rate[3][5] = 3280.8399;
        rate[3][6] = 1093.6133;
        // in
        rate[4][0] = 25.4;
        rate[4][1] = 2.54;
        rate[4][2] = 0.0254;
        rate[4][3] = 2.54e-5;
        rate[4][4] = 1;
        rate[4][5] = 0.0833333333;
        rate[4][6] = 0.0277777778;
        // ft
        rate[5][0] = 304.8;
        rate[5][1] = 30.48;
        rate[5][2] = 0.3048;
        rate[5][3] = 0.0003048;
        rate[5][4] = 12;
        rate[5][5] = 1;
        rate[5][6] = 0.3333333333;
        // yd
        rate[6][0] = 914.4;
        rate[6][1] = 91.44;
        rate[6][2] = 0.9144;
        rate[6][3] = 0.0009144;
        rate[6][4] = 36;
        rate[6][5] = 3;
        rate[6][6] = 1;
    }
}