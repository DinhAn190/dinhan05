package com.example.lab6th3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CurrencyAdapter extends ArrayAdapter<String> {

    Context context;
    String[] names;
    int[] flags;

    public CurrencyAdapter(Context context, String[] names, int[] flags) {
        super(context, R.layout.item_currency, names);
        this.context = context;
        this.names = names;
        this.flags = flags;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createItem(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createItem(position, convertView, parent);
    }

    private View createItem(int position, View convertView, ViewGroup parent) {
        View row = LayoutInflater.from(context).inflate(R.layout.item_currency, parent, false);

        ImageView img = row.findViewById(R.id.imgFlag);
        TextView name = row.findViewById(R.id.tvCurrency);

        img.setImageResource(flags[position]);
        name.setText(names[position]);

        return row;
    }
}
